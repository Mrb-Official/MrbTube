import os
import yt_dlp

video_url = os.environ.get("VIDEO_URL")
temp_path = '/storage/emulated/0/Download/'

# Agar by-chance cache path na mile, toh Download folder mein fallback kar lega
cache_path = os.environ.get("APP_CACHE_PATH", temp_path) 
file_path = os.path.join(cache_path, 'progress.txt')

# 👇 1. YEH RAHA APNA NAYA JASOOS FUNCTION 👇
# yt-dlp isko har second bulayega jab download chal raha hoga
def progress_chaser(d):
    if d['status'] == 'downloading':
        # Total size aur kitna download hua nikalna
        total = d.get('total_bytes') or d.get('total_bytes_estimate', 0)
        downloaded = d.get('downloaded_bytes', 0)
        
        if total > 0:
            percent = (downloaded / total) * 100
            
            # Har update par percentage ko file mein likh do
            try:
                with open(file_path, 'w') as f:
                    f.write(str(percent))
            except Exception:
                pass # Agar file likhne mein issue aaye toh download na ruke

if video_url:
    print("⏳ Python: Downloading High Quality Split Files...")
    
    # Dhyan rakhna, naam ke end mein strictly _MRB_Video aur _MRB_Audio hai
    ydl_opts_vid = {
        'format': 'bestvideo[ext=mp4]/bestvideo',
        'outtmpl': f'{temp_path}%(title)s_MRB_Video.%(ext)s',
        'nocheckcertificate': True,
        'quiet': False,
        'progress_hooks': [progress_chaser] # 👈 2. JASOOS KO YAHAN JOD DIYA
    }
    ydl_opts_aud = {
        'format': 'bestaudio[ext=m4a]/bestaudio',
        'outtmpl': f'{temp_path}%(title)s_MRB_Audio.%(ext)s',
        'nocheckcertificate': True,
        'quiet': False,
        'progress_hooks': [progress_chaser] # 👈 JASOOS KO AUDIO MEIN BHI JOD DIYA
    }
    
    try:
        with yt_dlp.YoutubeDL(ydl_opts_vid) as ydl:
            ydl.download([video_url])
        with yt_dlp.YoutubeDL(ydl_opts_aud) as ydl:
            ydl.download([video_url])
            
        print("✅ PYTHON DONE: Split files Download folder mein aa gayi!")
        
        # 3. Download poora hone par strictly 100.0 likh do taaki timer band ho jaye
        with open(file_path, 'w') as f:
            f.write("100.0")
            
    except Exception as e:
        print(f"❌ PYTHON ERROR: {e}")